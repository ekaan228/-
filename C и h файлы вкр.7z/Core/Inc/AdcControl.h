#ifndef _ADC_CONTROL_H_INCLUDED__
#define _ADC_CONTROL_H_INCLUDED__

#include "main.h"
#include "MotorTimerControl.h"

int min(int a, int b);

int max(int a, int b);

typedef struct {            
	uint16_t i;
	uint32_t summl;
	uint32_t summr;
	int16_t count;
	uint8_t stop;
} adc_channel;

void Update_ADC_Channel(volatile adc_channel* channel_data, uint8_t side);

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc);

static int l_raw = 0;
static int r_raw = 0;
static int l_value = 0;
static int r_value = 0;

int two_sensors_pid_callback(int side);

void adc_channel_reset(volatile adc_channel* ch, int count_value);

void set_new_count(int8_t side, int speed);

void Start_ADC(void);

#endif
