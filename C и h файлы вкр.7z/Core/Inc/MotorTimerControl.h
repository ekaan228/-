#ifndef _MOTOR_TIMER_CONTROL_H_INCLUDED__
#define _MOTOR_TIMER_CONTROL_H_INCLUDED__

#include "main.h"
#include "AdcControl.h"

typedef struct {
	int32_t current_speed;
	int32_t target_speed;
	uint32_t channel;

	GPIO_TypeDef* direction_port;
	uint16_t direction_pin;

	GPIO_TypeDef* sleep_port;
	uint16_t sleep_pin;

	GPIO_TypeDef* enable_port;
	uint16_t enable_pin;

	int step;
	int itr;
} structForMotors;


void set_target_speed(structForMotors* motor, int8_t speed);
	
void l_timer_control(const uint8_t enabled);
	
void r_timer_control(const uint8_t enabled);

void drive_control(const uint8_t enabled, uint16_t speed);

void l_stop(void);

void r_stop(void);

void PID (int);

void pid_drive(int , int);

void handle_motor_oc_callback(structForMotors* motor, uint16_t* toggle_flag, TIM_HandleTypeDef* htim, uint32_t channel, volatile uint32_t* current_pulse, int side, volatile uint32_t step_counter);

#endif
