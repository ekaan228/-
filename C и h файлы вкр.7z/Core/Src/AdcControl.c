#include "AdcControl.h"

volatile adc_channel data_l = {0,0,0,-1,0};  
volatile adc_channel data_r = {0,0,0,-1,0};

uint8_t start_summ = 0;
extern int full_speed;

static volatile uint16_t adc_values[2] = {0,0};

int min(int a, int b) {
	return a < b ? a : b;
}

int max(int a, int b) {
	return a > b ? a : b;
}


void Update_ADC_Channel(volatile adc_channel* data, uint8_t side)
{
	if (data->i < data->count) {
		data->summl += adc_values[0];
		data->summr += adc_values[1];
		data->i++;
	}
	else if (data->count == -1) {
		return;
	}
	else {
		if (!data->stop) {
			pid_drive(full_speed, side);
			data->stop = 1;
		}
	}
}


void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	UNUSED(hadc);
	Update_ADC_Channel(&data_l,0); 
	Update_ADC_Channel(&data_r,1);

}

int two_sensors_pid_callback(int side)
{
	const int LEFT_SENSOR_MIN = 1300;
	const int LEFT_SENSOR_MAX = 2600;
	const int LEFT_SENSOR_RANGE = LEFT_SENSOR_MAX - LEFT_SENSOR_MIN;

	const int RIGHT_SENSOR_MIN = 1420;
	const int RIGHT_SENSOR_MAX = 2630;
	const int RIGHT_SENSOR_RANGE = RIGHT_SENSOR_MAX - RIGHT_SENSOR_MIN;

	volatile adc_channel* data = (side == 0) ? &data_l : &data_r;

	int l_raw = data->summl / data->count;
	int r_raw = data->summr / data->count;

	int l_value = (max(LEFT_SENSOR_MIN, min(LEFT_SENSOR_MAX, l_raw)) - LEFT_SENSOR_MIN) * 1000 / LEFT_SENSOR_RANGE;
	int r_value = (max(RIGHT_SENSOR_MIN, min(RIGHT_SENSOR_MAX, r_raw)) - RIGHT_SENSOR_MIN) * 1000 / RIGHT_SENSOR_RANGE;

	return l_value - r_value;
}


void adc_channel_reset(volatile adc_channel* ch, int count_value) {
    ch->count = count_value;
    ch->summl = 0;
    ch->summr = 0;
    ch->i = 0;
    ch->stop = 0;
}

void set_new_count(int8_t side, int speed) {
	volatile float helper = (float)(speed+1) * 304347 / 168000000;
	helper = 0.6 * helper *	(TIM1->PSC+1);
	
	volatile adc_channel* target = (side == 0) ? &data_l : &data_r;
	adc_channel_reset(target, helper);
}

void Start_ADC(){
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)&adc_values, 2);
}
