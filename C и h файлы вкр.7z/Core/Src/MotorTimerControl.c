#include "MotorTimerControl.h"

structForMotors l_motor = {
    .current_speed = 1,
    .target_speed = 0,
    .channel = TIM_CHANNEL_1,

    .direction_port = LMDirection_GPIO_Port,
    .direction_pin = LMDirection_Pin,

    .sleep_port = LMSleep_GPIO_Port,
    .sleep_pin = LMSleep_Pin,

    .enable_port = LMEnable_GPIO_Port,
    .enable_pin = LMEnable_Pin,

    .step = 0,
    .itr = 0
};

structForMotors r_motor = {
    .current_speed = 1,
    .target_speed = 0,
    .channel = TIM_CHANNEL_2,

    .direction_port = RMDirection_GPIO_Port,
    .direction_pin = RMDirection_Pin,

    .sleep_port = RMSleep_GPIO_Port,
    .sleep_pin = RMSleep_Pin,

    .enable_port = RMEnable_GPIO_Port,
    .enable_pin = RMEnable_Pin,

    .step = 0,
    .itr = 0
};

extern volatile uint32_t step_counter_l;
extern volatile uint32_t step_counter_r;

volatile uint32_t channel1_current_pulse = 312;
volatile uint32_t channel2_current_pulse = 312;

static const uint32_t max_step = 1;

volatile int v = 0;
volatile int lv = 0;

int (*pidcallback)() = 0;

volatile uint32_t ccr_content;
volatile uint32_t ccr3_content;

int full_speed = 30;

int abs(int k) {
	if (k >= 0) {
		return k;
	}
	return -k;
}
int minn(int a, int b)
{
	return a < b ? a : b;
}

int maxx(int a, int b)
{
	return a > b ? a : b;
}
static const uint16_t MOTOR_SPEED_TIMER_STEPS[101] = {
	0, 59999, 9374, 6249, 4686, 3749, 3124, 2677, 2342, 2082, 1874, 1703, 1561, 1441, 1338, 1249, 1170, 1101, 1040, 985, 936, 891, 851, 814, 780,
	749, 720, 693, 668, 645, 624, 603, 584, 567, 550, 534, 519, 505, 492, 479, 467, 456, 445, 435, 425, 415, 406, 397, 389, 381, 374, 366, 359, 352,
	346, 339, 333, 327, 322, 316, 311, 306, 301, 296, 291, 287, 283, 278, 274, 270, 266, 263, 259, 255, 252, 249, 245, 242, 239, 236, 233, 230, 227,
	224, 222, 219, 217, 214, 212, 209, 207, 205, 202, 200, 198, 196, 194, 192, 190, 188, 186 //366
};
	
int signum(int value)
{
	return value == 0 ? 0 : (value < 0 ? -1 : 1);
}
	
void set_target_speed(structForMotors* motor, int8_t speed)
{
    motor->target_speed = speed;
}

void PID(int control_function_value){
	const float kp = 0.072, kd = 1.4;
	v = (int)(kp * control_function_value + kd * (control_function_value - lv));
	lv = control_function_value;
}

void pid_drive(int speed, int side) {
	structForMotors* motor = (side == 0) ? &l_motor : &r_motor;
	void (*timer_control_func)(uint8_t) = (side == 0) ? l_timer_control : r_timer_control;

	PID(two_sensors_pid_callback(side));

	int corrected_speed = (side == 0) ? speed + v : speed - v;

	if (abs(corrected_speed) > 70)
		corrected_speed = corrected_speed * 70 / abs(corrected_speed);

	HAL_GPIO_WritePin(motor->direction_port, motor->direction_pin,
	                  corrected_speed > 0 ? GPIO_PIN_RESET : GPIO_PIN_SET);

	set_target_speed(motor, corrected_speed);

	HAL_GPIO_WritePin(motor->enable_port, motor->enable_pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(motor->sleep_port, motor->sleep_pin, GPIO_PIN_SET);

}


void l_timer_control
	(const uint8_t enabled)
{
	if (enabled) {
		HAL_TIM_OC_Start_IT(&htim1, TIM_CHANNEL_1);

	}
	else {
		HAL_TIM_OC_Stop_IT(&htim1, TIM_CHANNEL_1);
	}
}

void r_timer_control(const uint8_t enabled)
{
	if (enabled) {
		HAL_TIM_OC_Start_IT(&htim1, TIM_CHANNEL_2);
	}
	else {
		HAL_TIM_OC_Stop_IT(&htim1, TIM_CHANNEL_2);
	}
}

void l_stop()
{
	l_timer_control(0);
	HAL_GPIO_WritePin(LMEnable_GPIO_Port, LMEnable_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(LMSleep_GPIO_Port, LMSleep_Pin, GPIO_PIN_RESET);
}

void r_stop()
{
	r_timer_control(0);
	HAL_GPIO_WritePin(RMEnable_GPIO_Port, RMEnable_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(RMSleep_GPIO_Port, RMSleep_Pin, GPIO_PIN_RESET);
}

void drive_control(const uint8_t enabled, uint16_t speed)
{
	full_speed = speed;
	if (enabled)
	{
		set_new_count(0, MOTOR_SPEED_TIMER_STEPS[abs(l_motor.current_speed)]);
		set_new_count(1, MOTOR_SPEED_TIMER_STEPS[abs(r_motor.current_speed)]);
	}
}

uint16_t boool1 = 0,boool2 = 0;

void handle_motor_oc_callback(structForMotors* motor,
                              uint16_t* toggle_flag,
                              TIM_HandleTypeDef* htim,
                              uint32_t channel,
                              volatile uint32_t* current_pulse,
                              int side, volatile uint32_t step_counter)
{
	const int old_speed = motor->current_speed;
	const int delta = motor->current_speed - motor->target_speed;

	if (abs(delta) > max_step)
		motor->current_speed -= signum(delta) * max_step;
	else
		motor->current_speed = motor->target_speed;

	if (motor->current_speed == 0)
		motor->current_speed = signum(motor->target_speed) * 2;

	ccr_content = HAL_TIM_ReadCapturedValue(htim, channel);
	*current_pulse = MOTOR_SPEED_TIMER_STEPS[abs(motor->current_speed)];
	__HAL_TIM_SET_COMPARE(htim, channel, (ccr_content + *current_pulse) & 0xFFFF);

	if (signum(old_speed) * signum(motor->current_speed) < 0)
		HAL_GPIO_WritePin(motor->direction_port, motor->direction_pin,
		                  motor->current_speed > 0 ? GPIO_PIN_RESET : GPIO_PIN_SET);

	if (!(*toggle_flag)) {
		set_new_count(side, MOTOR_SPEED_TIMER_STEPS[abs(motor->current_speed)]);
		step_counter++;
		
	}
	*toggle_flag = (*toggle_flag + 1) % 2;
}


void HAL_TIM_OC_DelayElapsedCallback(TIM_HandleTypeDef *htim)
{
	if (htim == &htim1 && htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1) {
		handle_motor_oc_callback(&l_motor, &boool1, htim, TIM_CHANNEL_1, &channel1_current_pulse, 0, step_counter_l);
	}
	else if (htim == &htim1 && htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2) {
		handle_motor_oc_callback(&r_motor, &boool2, htim, TIM_CHANNEL_2, &channel2_current_pulse, 1, step_counter_r);
	}
}

